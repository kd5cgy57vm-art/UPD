# UPD — Ultra Pro Delivery
Global business-document platform for legitimate invoices, receipts, quotations and payment records.

## Deploy on Railway
1. Add PostgreSQL to your Railway project.
2. Set DATABASE_URL from PostgreSQL in the UPD service.
3. Set a private SESSION_SECRET.
4. Deploy this repository.
5. Generate a public Railway domain.

Passwords are hashed with Argon2id and are never stored in plaintext.
This is a secure application foundation; production should additionally add verified email/phone flows, password reset, backups, comprehensive audit logs, monitoring and a security review.
